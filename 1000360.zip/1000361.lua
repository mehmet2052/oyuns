addappid(1000360) -- not the depot id, the APPID
addappid(1000361, 1, "b5b97451061159abe6184f5c46e24d7d3a1898c26611b7dce09483c6b5843f79") -- this is depot id and decrypt key
setManifestid(1000361, "5807120006120724935", 0)